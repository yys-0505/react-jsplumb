export const SHOW_LOADING = "show_loading";
export const HIDE_LOADING = "hide_loading";