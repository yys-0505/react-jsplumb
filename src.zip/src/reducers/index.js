import { combineReducers } from 'redux-immutable';
import pageReducer from './page'

export default combineReducers({
  page: pageReducer
});