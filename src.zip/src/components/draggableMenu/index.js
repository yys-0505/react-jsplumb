import React, { Component, Fragment} from 'react';
import $ from 'jquery';
import PropTypes from 'prop-types';
import http from '../../common/js/http';

class DraggableMenu extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tasks: []
    };
  }
  render () {
    return (
      <Fragment>
        <div className="box-card">
          <div className="header">任务列表</div>
          <div className="card-body">
            {this.renderItem()}
          </div>
        </div>
      </Fragment>
    )
  }
  componentDidMount () {
    this.getTaskList();
  }
  /**
   * @description 获取左侧菜单列表
   */
  getTaskList () {
    http.get("/data/taskList.json").then(res => {
      this.setState(() => ({
        tasks: res
      }), () => {
        this.makeItemDraggable();
      });
    });
  }
  renderItem () {
    return this.state.tasks.map((item, idx) => {
      return (
        <div className="item" key={idx} data-icon={item.icon} data-text={item.name} data-busitype={item.busiType}>
          <i style={{backgroundImage: 'url('+item.icon+')'}}></i>
          <span className="text">{item.name}</span>
        </div>
      )
    });
  }
  makeItemDraggable () {
    $(".box-card .item").draggable({
      scope: "plant",
      helper: "clone",
      containment: $("#"+ this.props.containerId)
    });
  }
}

DraggableMenu.defaultProps = {
  containerId: 'body'
};

DraggableMenu.propTypes = {
  containerId: PropTypes.string
};

export default DraggableMenu;