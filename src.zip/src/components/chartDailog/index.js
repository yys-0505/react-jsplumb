import React, { Component, Fragment } from 'react'
import { Modal, Layout } from 'antd'
import DraggableMenu from '../../components/draggableMenu'
import DroppablePanel from '../../components/droppablePanel'
import _css from './style.module.scss'

const { Sider, Content } = Layout;
class ChartDailog extends Component {
  constructor (props) {
    super(props);
    this.state = { visible: false }
  }
  render () {
    return (
      <Fragment>
        <Modal
          title="Basic Modal"
          maskClosable={false}
          width="80%"
          style={{ top: 30 }}
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          <Layout className={_css["scenario-config"]} id="dialog-container">
            <Sider className={_css.sider} theme="light">
              <DraggableMenu containerId="dialog-container"/>
            </Sider>
            <Content>
              <DroppablePanel ref={(panel) => {this.panel = panel}}/>
            </Content>
          </Layout>
        </Modal>
      </Fragment>
    )
  }
  handleOk = (e) => {
    console.log(e);
    this.setState({
      visible: false,
    });
  }

  handleCancel = (e) => {
    console.log(e);
    this.setState({
      visible: false,
    });
  }
}

export default ChartDailog;