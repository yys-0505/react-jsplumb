import React, { Fragment } from 'react';

class NotFound extends React.Component {
  render () {
    return (
      <Fragment>
        404
      </Fragment>
    )
  }
}

export default NotFound;