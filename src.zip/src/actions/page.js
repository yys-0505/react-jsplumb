import * as actionTypes from '../constant/actionTypes'
export const getShowLoadingAction = () => ({
  type: actionTypes.SHOW_LOADING
});

export const getHideLoadingAction = () => ({
  type: actionTypes.HIDE_LOADING
});